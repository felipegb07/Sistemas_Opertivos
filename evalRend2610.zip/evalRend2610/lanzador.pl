#!/usr/bin/perl
#**************************************************************
#         		Pontificia Universidad Javeriana
#     Autor: J. Corredor 
#	  Nombre Estudiante: 
#     Fecha: 
#     Materia: Sistemas Operativos
#     Tema: Taller de Evaluación de Rendimiento
#     Fichero: script automatización ejecución por lotes 
#****************************************************************/

$Path = `pwd`;
chomp($Path);

//Diferentes matrices las cuales estamos pidiendo que se ejecuten
@Nombre_Ejecutable = ("mxmPosixFxC","mxmPosixFxT","mxmForkFxC","mxmForkFxT");

//tamaños de las matrices
@Size_Matriz  = ("1800");

//Cantidad e hilos para cada matriz
@Num_Hilos    = (1,2,4,8,12,32);

//Numero de repeticiones
$Repeticiones = 30;
$Resultados	  = "Soluciones";
$Binarios	  = "bin";

/*Uso de este bucle para evitar hacer uso del for normal, ya que con este hacemos las iteraciones hasta
el final del archivo, de tal manera que podamos hacer que se pueda volver un código más dinámico*/
foreach $nombre (@Nombre_Ejecutable){
	foreach $size (@Size_Matriz){
		foreach $hilo (@Num_Hilos) {
			/*Resultados del archivo*/
			$file = "$Path/$Resultados/$nombre-".$size."-Hilos-".$hilo.".dat";
			printf("$file \n");
			for ($i=0; $i<$Repeticiones; $i++) {
				//Creación de las carpetas y los elementos para la lectura de cada proceso

				system("$Path/$Binarios/$nombre $size $hilo  >> $file");
				printf("$Path/$Binarios/$nombre $size $hilo \n");
			}
			close($file); //Cierre del archivo
		}
	}
}	
